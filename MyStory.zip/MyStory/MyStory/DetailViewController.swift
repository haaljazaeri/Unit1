import UIKit

class DetailViewController: UIViewController {

    var storyModel: StoryModel?
    
    @IBOutlet weak var detailImage: UIImageView!
    @IBOutlet weak var detailLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        showDetail(storyModel: storyModel)
    }
    
    private func showDetail(storyModel: StoryModel?){
        if let storyModel = storyModel {
            detailImage.image = storyModel.image
            detailLbl.text = storyModel.description
        }
    }
}
