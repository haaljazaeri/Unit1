

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var mainImage: UIImageView!
    
    var stories: [StoryModel] = []
    
    let  myCoolBackStory = StoryModel(image: UIImage(named: "spider2")!, description: "Peter Parker gained his powers by being bitten by a radioactive spider. Being bitten by a radioactive spider gave Peter the following powers: Superhuman Strength. Superhuman Speed, Superhuman Reflexes, Superhuman Durability, Healing Factor, “Spider-Sense” Alert, Heightened Senses, and Wall-crawling.")
    let  myWeakness = StoryModel(image: UIImage(named: "spider3")!, description: " His main weakness is the Ethyl Chloride pesticide, which dulls his reflexes, speed and spider-sense. But he has been shown to be quite resistant to it.")
    let  myGoal = StoryModel(image: UIImage(named: "spider4" )!, description: "Spider man's goal is to protect his neighborhood and to make his uncle Ben and aunt May proud. He started out aiming to be the friendly neighborhood spider man. Most recently, within Marvel's Avengers adaptation his aim was to join Tony Stark and the Avengers in protecting their universe.")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        stories = [myCoolBackStory, myWeakness, myGoal]
        mainImage.layer.cornerRadius = mainImage.frame.width/2;
    }
    
    
    @IBAction func contextAction(_ sender: UIButton) {
        performNavigation(storyModel: stories[sender.tag])
    }
    
    private func performNavigation(storyModel: StoryModel)
    {
        if let detailVC = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController {
            detailVC.storyModel = storyModel
            self.navigationController?.pushViewController(detailVC, animated: true);
        }
    }
}

