import Foundation
import UIKit

struct StoryModel {
    
    let image: UIImage
    let description: String
}
